"""
core/llm_client.py
-------------------
Provider-agnostic LLM client. Implement `LLMProvider` to add a new
backend — the analyzer, CLI, and dashboard never talk to a specific
API, only to this interface.
"""

from abc import ABC, abstractmethod

import requests

from utils.common import get_logger, retry_with_backoff

logger = get_logger(__name__)

RETRYABLE_ERRORS = (requests.exceptions.RequestException,)


class LLMProvider(ABC):
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("An API key is required to use this provider.")
        self.api_key = api_key

    @abstractmethod
    def generate(self, prompt: str, temperature: float = 0.3) -> str:
        raise NotImplementedError


class OpenAIProvider(LLMProvider):
    MODEL = "gpt-4o-mini"

    @retry_with_backoff(max_retries=3, base_delay=1.5, exceptions=RETRYABLE_ERRORS)
    def generate(self, prompt: str, temperature: float = 0.3) -> str:
        url = "https://api.openai.com/v1/chat/completions"
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.MODEL,
            "messages": [
                {"role": "system", "content": "You are an expert software engineer and code reviewer."},
                {"role": "user", "content": prompt},
            ],
            "temperature": temperature,
        }
        response = requests.post(url, headers=headers, json=payload, timeout=60)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()


class GeminiProvider(LLMProvider):
    MODEL = "gemini-2.0-flash"

    @retry_with_backoff(max_retries=3, base_delay=1.5, exceptions=RETRYABLE_ERRORS)
    def generate(self, prompt: str, temperature: float = 0.3) -> str:
        url = (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            f"{self.MODEL}:generateContent?key={self.api_key}"
        )
        payload = {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": temperature},
        }
        response = requests.post(url, json=payload, timeout=60)
        response.raise_for_status()
        data = response.json()
        return data["candidates"][0]["content"]["parts"][0]["text"].strip()


class MockProvider(LLMProvider):
    """Deterministic offline provider for tests and API-key-free exploration."""

    def __init__(self, api_key: str = "mock"):
        self.api_key = api_key

    def generate(self, prompt: str, temperature: float = 0.3) -> str:
        return (
            "[MOCK OUTPUT — no API key configured]\n"
            f"This is a placeholder LLM response for a prompt of {len(prompt)} chars. "
            "Set OPENAI_API_KEY or GEMINI_API_KEY in your .env for real analysis."
        )


_PROVIDERS = {"openai": OpenAIProvider, "gemini": GeminiProvider, "mock": MockProvider}


def get_provider(name: str, api_key: str) -> LLMProvider:
    name = name.lower().strip()
    if name not in _PROVIDERS:
        raise ValueError(f"Unknown provider '{name}'. Choose from: {list(_PROVIDERS)}")
    if name == "mock":
        return MockProvider(api_key or "mock")
    return _PROVIDERS[name](api_key)
