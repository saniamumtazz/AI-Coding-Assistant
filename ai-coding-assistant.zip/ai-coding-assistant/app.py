"""
app.py
------
Streamlit dashboard for the AI Coding Assistant. Same core/ engine as
cli.py — this is just an interactive front-end over it.

Run: streamlit run app.py
"""

import os

import streamlit as st
from dotenv import load_dotenv

from core.analyzer import CodeAssistant
from core.llm_client import get_provider
from core.github_client import fetch_file_from_github, fetch_pr_diff

load_dotenv()

st.set_page_config(page_title="AI Coding Assistant", page_icon="🧑‍💻", layout="wide")


def sidebar_config():
    st.sidebar.title("⚙️ Configuration")
    provider = st.sidebar.selectbox("LLM Provider", ["openai", "gemini", "mock"], index=0)
    key_env = f"{provider.upper()}_API_KEY"
    api_key = st.sidebar.text_input(
        f"{provider.title()} API Key", value=os.getenv(key_env, ""), type="password",
        help="Leave blank + pick 'mock' to explore the UI without an API key.",
    )
    st.sidebar.markdown("---")
    st.sidebar.caption("Static, deterministic checks run instantly and free. "
                       "The LLM pass adds judgment: bugs a parser can't see, "
                       "style, and explanations.")
    return provider, api_key


def get_assistant(provider, api_key):
    if provider != "mock" and not api_key:
        st.warning("No API key given — using the offline mock provider instead.")
        provider = "mock"
    return CodeAssistant(get_provider(provider, api_key or "mock"))


def main():
    st.title("🧑‍💻 AI Coding Assistant")
    st.caption("Explain, review, debug, and improve code — including files and PRs pulled straight from GitHub.")

    provider, api_key = sidebar_config()
    assistant = get_assistant(provider, api_key)

    tab1, tab2, tab3, tab4 = st.tabs(["📄 Paste Code", "🐛 Debug Traceback", "🔗 GitHub File", "🔀 GitHub PR Diff"])

    with tab1:
        code = st.text_area("Code", height=280, placeholder="Paste your code here...")
        language = st.text_input("Language", value="python")
        col1, col2, col3 = st.columns(3)
        do_explain = col1.button("Explain")
        do_review = col2.button("Review (static + AI)")
        do_improve = col3.button("Suggest Improvements")

        if code and do_explain:
            with st.spinner("Explaining..."):
                st.markdown(assistant.explain(code, language))
        if code and do_review:
            with st.spinner("Reviewing..."):
                result = assistant.review(code, language)
            if result.static_issues:
                st.subheader("Static Analysis")
                for issue in result.static_issues:
                    st.write(f"**L{issue.line}** [{issue.severity.upper()}] `{issue.category}` — {issue.message}")
            st.subheader("AI Review")
            st.markdown(result.llm_review)
        if code and do_improve:
            with st.spinner("Thinking of improvements..."):
                st.markdown(assistant.suggest_improvements(code, language))

    with tab2:
        code2 = st.text_area("Code", height=200, key="debug_code", placeholder="Paste the relevant code...")
        tb = st.text_area("Traceback / error message", height=150, placeholder="Paste the full traceback here...")
        language2 = st.text_input("Language", value="python", key="debug_lang")
        if st.button("Diagnose") and code2 and tb:
            with st.spinner("Diagnosing..."):
                st.markdown(assistant.debug(code2, tb, language2))

    with tab3:
        url = st.text_input("GitHub file URL", placeholder="https://github.com/owner/repo/blob/main/path/to/file.py")
        if st.button("Fetch & Review") and url:
            with st.spinner("Fetching from GitHub..."):
                gh_file = fetch_file_from_github(url, token=os.getenv("GITHUB_TOKEN"))
                language3 = gh_file.path.rsplit(".", 1)[-1] if "." in gh_file.path else "text"
            st.caption(f"{gh_file.owner}/{gh_file.repo}@{gh_file.ref}:{gh_file.path} — {len(gh_file.content)} chars")
            with st.expander("Show fetched source"):
                st.code(gh_file.content, language=language3)
            with st.spinner("Reviewing..."):
                result = assistant.review(gh_file.content, language3)
            if result.static_issues:
                st.subheader("Static Analysis")
                for issue in result.static_issues:
                    st.write(f"**L{issue.line}** [{issue.severity.upper()}] `{issue.category}` — {issue.message}")
            st.subheader("AI Review")
            st.markdown(result.llm_review)

    with tab4:
        pr_url = st.text_input("GitHub PR URL", placeholder="https://github.com/owner/repo/pull/123")
        if st.button("Fetch & Review Diff") and pr_url:
            with st.spinner("Fetching diff..."):
                diff_text = fetch_pr_diff(pr_url, token=os.getenv("GITHUB_TOKEN"))
            st.caption(f"Diff size: {len(diff_text)} chars")
            with st.expander("Show raw diff"):
                st.code(diff_text, language="diff")
            with st.spinner("Reviewing diff..."):
                st.markdown(assistant.review_diff(diff_text))


if __name__ == "__main__":
    main()
