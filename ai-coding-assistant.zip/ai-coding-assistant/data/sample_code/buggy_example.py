import os
import json
from math import *  # noqa

# TODO: replace this with a proper config loader
CACHE = {}


def add_item(item, bucket=[]):
    bucket.append(item)
    return bucket


def divide(a, b):
    try:
        return a / b
    except:
        pass


def load_config(path):
    with open(path) as f:
        data = eval(f.read())
    return data


def process_items(items):
    result = []
    for item in items:
        if item is not None:
            result.append(item * 2)
    return result
