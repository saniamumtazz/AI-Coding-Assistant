"""
core/prompts.py
-----------------
Prompt templates for each coding-assistant capability, kept separate
from orchestration logic so they can be tuned independently.
"""


def explain_prompt(code: str, language: str) -> str:
    return (
        f"Explain the following {language} code for a developer who is new to this codebase.\n"
        "Cover: (1) what it does at a high level, (2) a walk-through of the key logic, "
        "(3) any non-obvious behavior or edge cases worth knowing.\n"
        "Be concise but complete. Use short paragraphs or bullet points.\n\n"
        f"```{language}\n{code}\n```"
    )


def review_prompt(code: str, language: str, static_findings: str) -> str:
    findings_block = (
        f"Automated static analysis already found these issues:\n{static_findings}\n\n"
        if static_findings else ""
    )
    return (
        f"Review the following {language} code like a senior engineer doing a pull-request review.\n"
        f"{findings_block}"
        "Beyond what's listed above, look for: logic bugs, edge cases, readability, "
        "naming, error handling, and performance concerns. Don't repeat the automated "
        "findings verbatim — add judgment-based observations instead.\n"
        "Format your response as a short bullet list, each bullet starting with the "
        "severity in brackets: [HIGH], [MEDIUM], or [LOW].\n\n"
        f"```{language}\n{code}\n```"
    )


def improvement_prompt(code: str, language: str) -> str:
    return (
        f"Suggest concrete improvements to the following {language} code: better structure, "
        "naming, idiomatic patterns, performance, or readability. For each suggestion, briefly "
        "show a short before/after snippet if helpful. Do not suggest changes that alter behavior "
        "unless you flag them as a behavior change.\n\n"
        f"```{language}\n{code}\n```"
    )


def debug_prompt(code: str, traceback_text: str, language: str) -> str:
    return (
        f"The following {language} code raises an error. Diagnose the root cause and propose "
        "a concrete fix.\n\n"
        f"CODE:\n```{language}\n{code}\n```\n\n"
        f"ERROR / TRACEBACK:\n```\n{traceback_text}\n```\n\n"
        "Structure your answer as:\n"
        "ROOT CAUSE: <one or two sentences>\n"
        "FIX: <the corrected code or a clear description of the change>\n"
        "WHY THIS WORKS: <brief explanation>"
    )


def diff_review_prompt(diff_text: str) -> str:
    return (
        "You are reviewing a pull request diff. Write PR-review-style comments: point out bugs, "
        "risky changes, missing tests, or style issues introduced by this diff specifically "
        "(ignore unchanged context lines except where needed for understanding).\n"
        "Format as a short bullet list, each starting with the changed file name in backticks.\n\n"
        f"```diff\n{diff_text}\n```"
    )
