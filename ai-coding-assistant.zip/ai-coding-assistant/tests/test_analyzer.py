from core.analyzer import CodeAssistant
from core.llm_client import MockProvider


def test_review_combines_static_and_llm_output():
    assistant = CodeAssistant(MockProvider())
    code = "def f(x=[]):\n    x.append(1)\n    return x\n"
    result = assistant.review(code, "python")
    assert any(i.category == "mutable-default" for i in result.static_issues)
    assert "MOCK OUTPUT" in result.llm_review


def test_review_skips_static_checks_for_non_python():
    assistant = CodeAssistant(MockProvider())
    result = assistant.review("console.log('hi')", "javascript")
    assert result.static_issues == []
    assert "MOCK OUTPUT" in result.llm_review


def test_explain_and_improve_return_provider_output():
    assistant = CodeAssistant(MockProvider())
    assert "MOCK OUTPUT" in assistant.explain("x = 1", "python")
    assert "MOCK OUTPUT" in assistant.suggest_improvements("x = 1", "python")


def test_debug_and_diff_review_return_provider_output():
    assistant = CodeAssistant(MockProvider())
    assert "MOCK OUTPUT" in assistant.debug("x = 1/0", "ZeroDivisionError", "python")
    assert "MOCK OUTPUT" in assistant.review_diff("+ x = 1")
