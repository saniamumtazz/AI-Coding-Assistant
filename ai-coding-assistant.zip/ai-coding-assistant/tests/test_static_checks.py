from core.static_checks import analyze_python_source


SAMPLE = open("data/sample_code/buggy_example.py", encoding="utf-8").read()


def test_detects_bare_except():
    issues = analyze_python_source(SAMPLE)
    categories = [i.category for i in issues]
    assert "error-handling" in categories


def test_detects_mutable_default_argument():
    issues = analyze_python_source(SAMPLE)
    messages = " ".join(i.message for i in issues)
    assert "mutable default argument" in messages
    assert "add_item" in messages


def test_detects_wildcard_import():
    issues = analyze_python_source(SAMPLE)
    categories = [i.category for i in issues]
    assert "imports" in categories


def test_detects_eval_usage():
    issues = analyze_python_source(SAMPLE)
    messages = " ".join(i.message for i in issues)
    assert "eval" in messages.lower()


def test_detects_todo_marker():
    issues = analyze_python_source(SAMPLE)
    categories = [i.category for i in issues]
    assert "housekeeping" in categories


def test_valid_code_has_no_bare_except_or_eval():
    clean_code = "def add(a, b):\n    return a + b\n"
    issues = analyze_python_source(clean_code)
    categories = {i.category for i in issues}
    assert "error-handling" not in categories
    assert "security" not in categories


def test_syntax_error_is_reported_gracefully():
    broken = "def f(:\n    pass"
    issues = analyze_python_source(broken)
    assert len(issues) == 1
    assert issues[0].category == "syntax"
