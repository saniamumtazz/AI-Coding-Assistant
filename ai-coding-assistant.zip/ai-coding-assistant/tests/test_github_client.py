import pytest

from core.github_client import resolve_raw_url, parse_pr_url


def test_resolve_raw_url_converts_blob_url():
    url = "https://github.com/psf/requests/blob/main/src/requests/models.py"
    raw = resolve_raw_url(url)
    assert raw == "https://raw.githubusercontent.com/psf/requests/main/src/requests/models.py"


def test_resolve_raw_url_passes_through_existing_raw_url():
    raw_url = "https://raw.githubusercontent.com/psf/requests/main/src/requests/models.py"
    assert resolve_raw_url(raw_url) == raw_url


def test_resolve_raw_url_rejects_non_github_url():
    with pytest.raises(ValueError):
        resolve_raw_url("https://example.com/not/a/github/url.py")


def test_parse_pr_url_extracts_owner_repo_number():
    owner, repo, number = parse_pr_url("https://github.com/octocat/Hello-World/pull/42")
    assert owner == "octocat"
    assert repo == "Hello-World"
    assert number == 42


def test_parse_pr_url_rejects_non_pr_url():
    with pytest.raises(ValueError):
        parse_pr_url("https://github.com/octocat/Hello-World")
