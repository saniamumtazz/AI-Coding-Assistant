"""
utils/common.py
----------------
Shared utilities: logging setup and a retry-with-exponential-backoff
decorator used around every LLM API call, so a flaky connection or a
momentary rate limit doesn't crash a review/debug session.
"""

import functools
import logging
import time
from typing import Callable, Tuple, Type


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        formatter = logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
            datefmt="%H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger


def retry_with_backoff(
    max_retries: int = 3,
    base_delay: float = 1.0,
    exceptions: Tuple[Type[BaseException], ...] = (Exception,),
):
    """Retries a function with exponential backoff (base_delay * 2^attempt)
    when one of `exceptions` is raised. Re-raises after the last attempt."""

    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            logger = get_logger(func.__module__)
            last_exc = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as exc:  # noqa: BLE001
                    last_exc = exc
                    if attempt == max_retries:
                        logger.error(
                            "'%s' failed after %d attempts: %s",
                            func.__name__, attempt + 1, exc,
                        )
                        raise
                    delay = base_delay * (2 ** attempt)
                    logger.warning(
                        "'%s' failed (attempt %d/%d): %s — retrying in %.1fs",
                        func.__name__, attempt + 1, max_retries + 1, exc, delay,
                    )
                    time.sleep(delay)
            raise last_exc  # pragma: no cover

        return wrapper

    return decorator
