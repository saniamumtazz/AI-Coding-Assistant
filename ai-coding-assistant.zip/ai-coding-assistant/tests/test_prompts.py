from core.prompts import explain_prompt, review_prompt, improvement_prompt, debug_prompt, diff_review_prompt


def test_explain_prompt_includes_code_and_language():
    prompt = explain_prompt("print('hi')", "python")
    assert "print('hi')" in prompt
    assert "```python" in prompt


def test_review_prompt_includes_static_findings_when_given():
    prompt = review_prompt("x = 1", "python", "- L1 [WARNING] (imports) unused import")
    assert "unused import" in prompt
    assert "senior engineer" in prompt


def test_review_prompt_omits_findings_block_when_empty():
    prompt = review_prompt("x = 1", "python", "")
    assert "Automated static analysis" not in prompt


def test_debug_prompt_includes_traceback_and_structure_labels():
    prompt = debug_prompt("x = 1 / 0", "ZeroDivisionError: division by zero", "python")
    assert "ZeroDivisionError" in prompt
    assert "ROOT CAUSE" in prompt
    assert "FIX" in prompt


def test_diff_review_prompt_wraps_diff_block():
    prompt = diff_review_prompt("+ added line\n- removed line")
    assert "```diff" in prompt
    assert "added line" in prompt
